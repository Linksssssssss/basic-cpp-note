#include<iostream>
#include<string>

#ifndef PACKAGE_H
#define PACKAGE_H

class Package {
public:
    Package(const std::string &,const std::string &,const std::string &,const std::string &,
        const std::string &,const std::string &,const std::string &,const std::string &,const std::string &,
        const std::string &,double=0.0,double=0.0);
    virtual double calculateCost() const;
    double getweight() const;
    double getcost_per_ounce() const;
    virtual std::string get_address_send() const;
    virtual std::string get_address_recieve() const;
    virtual ~Package(){ }
private:
    std::string name_send;
    std::string name_recieve;
    std::string address_send;
    std::string address_recieve;
    std::string city_send;   
    std::string city_recieve;
    std::string state_send;
    std::string state_recieve;
    std::string zip_send;
    std::string zip_recieve;
    double weight;
    double cost_per_ounce;
};
#endif
// Package.h