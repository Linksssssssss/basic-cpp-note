#include<iostream>
#include<vector>
#include"Package.h"
#include"Twodaypackage.h"
#include"OvernightPackage.h"
using namespace std;

int main()
{
    vector<Package*> packages(2);
    Twodaypackage t("SALAH","TRENT","Anfield","United","Liverpool","London","England","England","123","456",1.0,2.0,15.0);
    OvernightPackage o("SALAH","TRENT","Anfield","United","Liverpool","London","England","England","123","456",1.0,2.0,3.0);
    packages[0]=&t;
    packages[1]=&o;
    double totalmoney;
    for(const Package* packag:  packages){
        cout<<"Sender address:     "<<packag->get_address_send()<<"\n"
            <<"Reciever address:   "<<packag->get_address_recieve()<<"\n";
        totalmoney+=packag->calculateCost();
    }
    cout<<"total shipping cost for all Packages is:     "<<totalmoney<<endl;
    return 0;
}
