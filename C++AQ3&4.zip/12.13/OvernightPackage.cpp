#include<iostream>
#include<string>
#include<stdexcept>
#include "OvernightPackage.h"
using namespace std;

OvernightPackage::OvernightPackage(const string &name_send,const string &name_recieve,const string &address_send,const string &address_recieve,const string &city_send,
    const string &city_recieve,const string &state_send,const string &state_recieve,const string &zip_send,const string &zip_recieve,
    double w,double cpn, double efp)
    :Package(name_send,name_recieve,address_send,address_recieve,city_send,city_recieve,state_send,state_recieve,zip_send,zip_recieve,w,cpn){
        if(efp>0){
            this->extra_fee_per_ounce=efp;
        }
        else{
            throw invalid_argument("extra_fee_per_ounce must be >=0.0");
        }
    }
double OvernightPackage::calculateCost() const{
    return Package::getweight()*(Package::getcost_per_ounce()+extra_fee_per_ounce);
}
string OvernightPackage::get_address_send() const{
    return Package::get_address_send();
}
string OvernightPackage::get_address_recieve() const{
    return Package::get_address_recieve();
}