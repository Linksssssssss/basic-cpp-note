#include<iostream>
#include<string>
#include "Package.h"

#ifndef OVERNIGHTPACKAGE_H
#define OVERNIGHTPACKAGE_H

class OvernightPackage : public Package {
public:
    virtual double calculateCost() const override;
    OvernightPackage(const std::string &,const std::string &,const std::string &,const std::string &,
        const std::string &,const std::string &,const std::string &,const std::string &,const std::string &,
        const std::string &,double=0.0,double=0.0,double=0.0);
    virtual ~OvernightPackage(){ }
    virtual std::string get_address_send() const override;
    virtual std::string get_address_recieve() const override;
private:
    double extra_fee_per_ounce; 
};



#endif