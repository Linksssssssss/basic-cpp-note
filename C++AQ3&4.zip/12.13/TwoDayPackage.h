#ifndef Twodaypackage_H
#define Twodaypackage_H


#include<iostream>
#include<string>
#include "Package.h"

class Twodaypackage : public Package {
public:
    Twodaypackage(const std::string &,const std::string &,const std::string &,const std::string &,
    const std::string &,const std::string &,const std::string &,const std::string &,const std::string &,
    const std::string &,double=0.0,double=0.0,double=0.0);
    virtual ~Twodaypackage(){ }
    virtual double calculateCost() const override;
    virtual std::string get_address_send() const override;
    virtual std::string get_address_recieve() const override;
private:
    double flat_fee;
};



#endif 