#include<iostream>
#include<string>
#include<stdexcept>
#include "TwoDayPackage.h"
using namespace std;

Twodaypackage::Twodaypackage(const string &name_send,const string &name_recieve,const string &address_send,const string &address_recieve,const string &city_send,
    const string &city_recieve,const string &state_send,const string &state_recieve,const string &zip_send,const string &zip_recieve,
    double w,double cpn, double ff)
    :Package(name_send,name_recieve,address_send,address_recieve,city_send,city_recieve,state_send,state_recieve,zip_send,zip_recieve,w,cpn){
        if(ff>0){
            this->flat_fee=ff;
        }
        else{
            throw invalid_argument("flat_fee must be >=0.0");
        }
    }
double Twodaypackage::calculateCost() const{
    return Package::calculateCost()+flat_fee;
}