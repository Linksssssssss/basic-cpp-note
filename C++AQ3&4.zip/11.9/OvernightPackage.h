#include<iostream>
#include<string>
#include "Package.h"

#ifndef OVERNIGHTPACKAGE_H
#define OVERNIGHTPACKAGE_H

class OvernightPackage : public Package {
public:
    double calculateCost() const;
    OvernightPackage(const std::string &,const std::string &,const std::string &,const std::string &,
        const std::string &,const std::string &,const std::string &,const std::string &,const std::string &,
        const std::string &,double=0.0,double=0.0,double=0.0);
private:
    double extra_fee_per_ounce; 
};



#endif