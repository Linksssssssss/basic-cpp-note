#include<iostream>
#include<string>
#include "Package.h"
#include "Twodaypackage.h"
#include "OvernightPackage.h"
using namespace std;

void test()
{
    Package p("SALAH","TRENT","Anfield","United","Liverpool","London","England","England","123","456",1.0,2.0);
    cout<<"Package cost: "<<p.calculateCost()<<endl;
    Twodaypackage t("SALAH","TRENT","Anfield","United","Liverpool","London","England","England","123","456",1.0,2.0,15.0);
    cout<<"Twodaypackage cost: "<<t.calculateCost()<<endl;
    OvernightPackage o("SALAH","TRENT","Anfield","United","Liverpool","London","England","England","123","456",1.0,2.0,3.0);
    cout<<"OvernightPackage cost: "<<o.calculateCost()<<endl;
}
int main(){
    test();
    return 0;
}