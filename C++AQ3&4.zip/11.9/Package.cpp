#include<iostream>
#include<string>
#include "Package.h"
using namespace std;

double Package::calculateCost() const {
    return weight * cost_per_ounce;
}
Package::Package(const string &name_send,const string &name_recieve,const string &address_send,const string &address_recieve,const string &city_send,
    const string &city_recieve,const string &state_send,const string &state_recieve,const string &zip_send,const string &zip_recieve,
    double w,double cpn):name_send(name_send),name_recieve(name_recieve),address_recieve(address_recieve),address_send(address_send),
    city_send(city_send),city_recieve(city_recieve),state_send(state_send),state_recieve(state_recieve),zip_send(zip_send),zip_recieve(zip_recieve)
    {
        if(w>0.0&&cpn>0.0){
            this->weight=w;
            this->cost_per_ounce=cpn;
        }
        else{
            throw invalid_argument("both weight and cost_per_ounce must be >=0.0");
        }
    }
double Package::getweight() const{
    return this->weight;
}
double Package::getcost_per_ounce() const{
    return this->cost_per_ounce;
}