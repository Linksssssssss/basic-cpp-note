#ifndef Twodaypackage_H
#define Twodaypackage_H


#include<iostream>
#include<string>
#include "Package.h"

class Twodaypackage : public Package {
public:
    Twodaypackage(const std::string &,const std::string &,const std::string &,const std::string &,
    const std::string &,const std::string &,const std::string &,const std::string &,const std::string &,
    const std::string &,double=0.0,double=0.0,double=0.0);
    double calculateCost() const;
private:
    double flat_fee;
};



#endif 