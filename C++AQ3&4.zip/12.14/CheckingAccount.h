# include<iostream>
#include"Account.h"
#ifndef CHECKINGACCOUNT_H
#define CHECKINGACCOUNT_H
class CheckingAccount: public Account{
private:
    double transactionFee;
public:
    CheckingAccount(double=0.0, double=0.0);
    virtual void credit(double=0.0);
    virtual void debit(double=0.0);
    virtual ~CheckingAccount(){ }
};
# endif