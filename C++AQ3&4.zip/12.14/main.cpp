#include<iostream>
#include<vector>
#include<typeinfo>
#include"CheckingAccount.h"
#include"Account.h"
#include"SavingsAccount.h"
using namespace std;

void test(){
    CheckingAccount account2(10000.0, 1.0);
    SavingsAccount account3(10000.0, 0.05);
    vector<Account*> accounts(2);
    accounts[0] = &account2;
    accounts[1] = &account3;
    for(Account* account: accounts){
        account->credit(1000.0);
        account->debit(500.0);
        SavingsAccount* savingsAccount = dynamic_cast<SavingsAccount*>(account);
        if(savingsAccount!=nullptr){
            double interest=savingsAccount->calculateInterest();
            savingsAccount->credit(interest);
        }
        cout<<"current balance in    "<<typeid(*account).name()<<" is:    "<<account->getBalance()<<"\n";
    }
}


int main(){
    test();
    return 0;
}/*
    1.用户能够取款和存款
    2.savingsAccount类能够计算利息
    3. 打印信息
*/