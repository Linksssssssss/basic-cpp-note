#ifndef ACCOUNT_H
#define ACCOUNT_H

class Account {
public:
    Account(double =0.0);
    virtual void credit(double=0.0);
    virtual void debit(double=0.0);
    double getBalance() const;
    virtual ~Account(){ }
private:
    double balance;
};
# endif