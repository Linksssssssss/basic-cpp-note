# include"Account.h"
# ifndef SAVINGSACCOUNT_H
# define SAVINGSACCOUNT_H
class SavingsAccount: public Account{
private:
    double interestRate;
public:
    SavingsAccount(double=0.0, double=0.0);
    double calculateInterest()const;
};
# endif