#include<iostream>
#include"CheckingAccount.h"
#include"Account.h"
#include"SavingsAccount.h"
using namespace std;

void test(){
    Account account1(10000.0);
    account1.credit(1000.0);
    account1.debit(500.0);
    account1.debit(20000.0);
    cout << "Account balance: " << account1.getBalance() << endl;
    CheckingAccount account2(10000.0, 1.0);
    account2.credit(2000.0);
    account2.debit(600.0);
    cout << "CheckAccount balance: " << account2.getBalance() << endl;
    SavingsAccount account3(10000.0, 0.05);
    cout<<"The intrest in savingsaccount is:   "<<account3.calculateInterest();
}


int main(){
    test();
    return 0;
}