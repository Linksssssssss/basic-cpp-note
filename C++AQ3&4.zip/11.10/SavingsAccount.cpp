#include"SavingsAccount.h"
#include<iostream>
using namespace std;

SavingsAccount::SavingsAccount(double initialBalance, double rate) 
    : Account(initialBalance) {
    this->interestRate = rate;
}
double SavingsAccount::calculateInterest() const {
    return getBalance() * interestRate;
}