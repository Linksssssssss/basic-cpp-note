#include<iostream>
#include"CheckingAccount.h"
using namespace std;

CheckingAccount::CheckingAccount(double initialBalance, double fee) 
    : Account(initialBalance) {
    this->transactionFee=fee;
}
void CheckingAccount::credit(double amount) {
    Account::credit(amount-transactionFee);
}
void CheckingAccount::debit(double amount) {
    if (amount-transactionFee>Account::getBalance()) {
        cerr<<"Debit amount exceeded account balance."<<endl;
    } else {
        Account::debit(amount-transactionFee);
    }
}