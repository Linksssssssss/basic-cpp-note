# include<iostream>
# include"Account.h"
using namespace std;

Account::Account(double balance){
    if(balance>=0.0){
        this->balance=balance;
    }
    else{
        this->balance=0.0;
        cerr << "Initial balance was invalid." << endl;
    }
}
void Account::credit(double amount){
    this->balance+=amount;
}
void Account::debit(double withdrawal){
    if(withdrawal>this->balance){
        cerr<<"Debit amount exceeded account balance."<<endl;
    }
    else{
        this->balance-=withdrawal;
    }
}
double Account::getBalance()const{
    return this->balance;
}