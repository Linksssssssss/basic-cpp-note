# include<iostream>
#include"Account.h"
#ifndef CHECKINGACCOUNT_H
#define CHECKINGACCOUNT_H
class CheckingAccount: public Account{
private:
    double transactionFee;
public:
    CheckingAccount(double=0.0, double=0.0);
    void credit(double=0.0);
    void debit(double=0.0);
};
# endif