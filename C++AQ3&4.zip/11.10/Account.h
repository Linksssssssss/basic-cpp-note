#ifndef ACCOUNT_H
#define ACCOUNT_H

class Account {
public:
    Account(double =0.0);
    void credit(double=0.0);
    void debit(double=0.0);
    double getBalance() const;
private:
    double balance;
};
# endif