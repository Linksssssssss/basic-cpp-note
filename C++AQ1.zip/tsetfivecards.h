#include<iostream>
#include<string>
#include<array>
#include<algorithm>
using namespace std;

template<typename T>
static bool devide(T& m,int b,int c,int d,int e)
{
    array<string,5>processed_newdeck;
    for(int i=0;i<5;i++)
    {
        processed_newdeck[i]=m[i].substr(d,e);
    }
    if(processed_newdeck[b]==processed_newdeck[c])
    {
        return true;
    }
    return false;
}//function to see if there are a pair

template<typename T>
int routine(T& n,int i)
{
    for(int j=i+1;j<5;j++)
    {
        if(devide(n,i,j,0,5))
        {
            return j;
        }
    }
    return 0;
}//function for scuuincting the whole code

bool checkapair(array<string,5>a)
{
    for(int i=0;i<4;i++)
    {
        if(routine(a,i))
        {
            return true;
        }
    }
    return false;
}//Determine whether the hand contains a pair

bool checktwopairs(array<string,5>a)
{
    int count=0;
    int matched=-1;
    for(int i=0;i<4;i++)
    {
        if(matched!=i&&routine(a,i))
        {
            count++;
            matched=routine(a,i);
        }
    }
    if(count==2)
    {
        return true;
    }
    return false;
}//Determine whether the hand contains two pairs

bool checkthree(array<string,5>a)
{
    for(int i=0;i<4;i++)
    {
        if(routine(a,i))
        {
            int b=routine(a,i);
            if(routine(a,b))
            {
                return true;
            }
        }
    }
    return false;
}//Determine whether the hand contains three of a kind (e.g., three jacks).

bool checkfour(array<string,5>a)
{
    for(int i=0;i<4;i++)
    {
        if(routine(a,i))
        {
            int b=routine(a,i);
            if(routine(a,b))
            {
                int c=routine(a,b);
                if(routine(a,c))
                {
                    return true;
                }
            }
        }
    }
    return false;
}//Determine whether the hand contains four of a kind (e.g., four aces)

bool checkflush(array<string,5>a)
{
    int count=0;
    if(routine(a,-1))
    {
        count++;
    }
    if(count==4)
    {
        return true;
    }
    return false;
}//Determine whether the hand contains a flush (i.e., all five cards of the same suit).

bool checkapair(array<int,5>a)
{
    for(int i=0;i<4;i++)
    {
        for(int j=i+1;j<5;j++)
        {
            if(a[i]==a[j])
            {
                return true;
            }
        }
    }
    return false;
}//check pair for function checkstraight

int findnumber(string test)
{
    if(test=="Ace  ")
    {
        return 1;
    }
    if(test=="2    ")
    {
        return 2;
    }
    if(test=="3    ")
    {
        return 3;
    }
    if(test=="4    ")
    {
        return 4;
    }
    if(test=="5    ")
    {
        return 5;
    }
    if(test=="6    ")
    {
        return 6;
    }if(test=="7    ")
    {
        return 7;
    }
    if(test=="8    ")
    {
        return 8;
    }
    if(test=="9    ")
    {
        return 9;
    }
    if(test=="10   ")
    {
        return 10;
    }
    if(test=="Jack ")
    {
        return 11;
    }
    if(test=="Queen")
    {
        return 12;
    }
    if(test=="King ")
    {
        return 13;
    }
    return -1;
}//convert the face value to a number
bool checkstraight(array<string,5>a)
{
    array<int,5> num;
    for(int i=0;i<5;i++)
    {
        num[i]=findnumber(a[i].substr(0,5));
    }
    sort(&num[0],&num[4]);
    if((num[0]-num[4]==-4)&&(checkapair(num)==false))
    {
        return true;
    }
    return false;
}//Determine whether the hand contains a straight (i.e., five cards of consecutive face values).