#include<iostream>
#include<string>
#include<array>

#include"DeckOfCards.h"
#include"tsetfivecards.h"
using namespace std;

static array<string,5> newdeck;

void test01()
{
    int j=0;
    DeckOfCards deckss;
    deckss.shuffle();
    while(deckss.moreCards9_24())
    {
        newdeck[j]=deckss.dealCard();
        cout<<newdeck[j]<<endl;//print out the cards
        j++;
    }
}//creating an object
int main()
{
    //below are all functions for 9.23
    DeckOfCards deck1;
    deck1.shuffle();
    while(deck1.moreCards9_23())
    {
        cout<<deck1.dealCard()<<endl;
    }
    cout<<"\n";

    //below are all functions for 9.24
    test01();
    cout<<boolalpha<<checkapair(newdeck)<<endl;
    cout<<checkflush(newdeck)<<endl;
    cout<<checkfour(newdeck)<<endl;
    cout<<checkthree(newdeck)<<endl;
    cout<<checkstraight(newdeck)<<endl;
    cout<<checktwopairs(newdeck)<<endl;
    
    return 0;
}