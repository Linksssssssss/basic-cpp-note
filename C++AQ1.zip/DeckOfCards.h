#include<iostream>
#include<string>
#include<array>
#include"Cardsss.h"
#include<ctime>
#include <random>
#ifndef DECKOFCARDS_H
#define DECKOFCARDS_H

class DeckOfCards
{
public:
    DeckOfCards()
    {
        srand(static_cast<unsigned int>(time(NULL)));
        for(int i=0;i<52;i++)
        {
            Card card(i%13, i/13);
            deck[i] = card.toString();
        }
    }//default constructor
    void shuffle()
    {
        for(int j=0;j<52;j++)
        {
            int num=rand()%51;
            std::string temp;
            temp=deck[j];
            deck[j]=deck[num];
            deck[num]=temp;
        }
    }//ramdomly shuffle the cards
    std::string dealCard()
    {
        return deck[this->currentCard++];
    }
    bool moreCards9_23()
    {
        if(currentCard==52)
        {
            return false;
        }
        else
        {
            return true;
        }
    }//a function checking more cards in task 9.23
    bool moreCards9_24()
    {
        if(currentCard==5)
        {
            return false;
        }
        else
        {
            return true;
        }
    }//a function checking more cards in task 9.24
private:
    int currentCard=0;

    std::array<std::string,52> deck;//storing the cards
};
#endif 