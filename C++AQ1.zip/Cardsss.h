#include<iostream>
#include<string>
#include<array>

#ifndef CARDSSS_H
#define CARDSSS_H

class Card
{
public:
    Card(int face, int suit)
    {
        this->face = face;
        this->suit = suit;
    };//constructor

    static std::array<std::string, 4> suits;
    static std::array<std::string, 13> faces;

    std::string toString()
    {
        return faces[face] + "  of " + suits[suit];
    }//return the Cards
private:
    int face;
    int suit;

};

std::array<std::string, 4> Card::suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
std::array<std::string, 13> Card::faces = {"Ace  ", "2    ", "3    ", "4    ", "5    ", "6    ", "7    ", "8    ", "9    ", "10   ", "Jack ", "Queen", "King "};
#endif // CARDSSS_H