# ifndef HARDWARELIST_H
# define HARDWARELIST_H

# include<string>

class HardwareList{
private:
    unsigned int recordNumber;
    char toolName[100];
    unsigned int quantity;
    double cost;
public:
    HardwareList(unsigned int recordNumber){
        this->recordNumber=recordNumber;
    }
    HardwareList(unsigned int recordNumber, const std::string &toolName, unsigned int quantity, double cost){
        this->recordNumber=recordNumber;
        setlastname(toolName);
        this->quantity=quantity;
        this->cost=cost;
    }
    unsigned int getrecordNumber()const{
        return recordNumber;
    }
    HardwareList(){}
    void setlastname(const std::string &toolName){
    int length = toolName.size();
    length=(length<100?length:99);
    toolName.copy(this->toolName,length);
    this->toolName[length]='\0';
    }
    std::string gettoolName()const{
        return std::string(toolName);
    }
    unsigned int getquantity()const{
        return quantity;
    }
    double getcost()const{
        return cost;
    }
};




# endif