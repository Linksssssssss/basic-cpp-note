# include<iostream>
# include<fstream>
# include "hardwarelist.h"
using namespace std;

void updaterecord(fstream &hardwarefile);
void showhardwarelist(fstream &hardwarefile);
void deletehardwarelist(fstream &hardwarefile);

int main(){
    fstream hardwareFile("hardware.dat", ios::in|ios::out|ios::binary);
    if(!hardwareFile){
        cerr<<"File doesn't exist"<<endl;
        exit(EXIT_FAILURE);
    }
    for(unsigned int i=0;i<100;++i){
        HardwareList h(i+1);
        hardwareFile.write(reinterpret_cast<const char*>(&h),sizeof(HardwareList));
    }
    for(unsigned int i=0;i<8;i++){
        updaterecord(hardwareFile);
    }
    showhardwarelist(hardwareFile);
    deletehardwarelist(hardwareFile);
    hardwareFile.close();
    return 0;
}

void updaterecord(fstream &hardwarefile){
    unsigned int accountNumber;
    cout<<"Enter the account number to update: ";
    cin>>accountNumber;
    hardwarefile.seekg((accountNumber - 1)*sizeof(HardwareList));
    HardwareList h;
    hardwarefile.read(reinterpret_cast<char*>(&h),sizeof(HardwareList));
    if(h.getrecordNumber()==0){
        cout<<"No record found for account number "<<accountNumber<<endl;
        return;
    }
    else{
        string toolName;
        unsigned int quantity;
        double cost;
        cout<<"Enter the new tool name: ";
        cin.ignore();
        getline(cin, toolName);
        cout<<"Enter the new quantity: ";
        cin>>quantity;
        cout<<"Enter the new cost: ";
        cin>>cost;
        cout<<endl;
        HardwareList newRecord(accountNumber, toolName, quantity, cost);
        hardwarefile.seekp((accountNumber - 1)*sizeof(HardwareList));
        hardwarefile.write(reinterpret_cast<char*>(&newRecord),sizeof(HardwareList));
    }
}
void showhardwarelist(fstream &hardwarefile){
    hardwarefile.seekg(0);
    HardwareList h;
    cout<<"showing records with real data"<<endl;
    while(hardwarefile.read(reinterpret_cast<char*>(&h), sizeof(HardwareList))){
        if(h.gettoolName().empty()){
            continue;
        }
        cout<<"Record Number: "<<h.getrecordNumber()<<endl;
        cout<<"Tool Name: "<<h.gettoolName()<<endl;
        cout<<"Quantity: "<<h.getquantity()<<endl;
        cout<<"Cost: "<<h.getcost()<<endl;
        cout<<endl;
    }
}
void deletehardwarelist(fstream &hardwarefile){
    unsigned int accountNumber;
    cout<<"Enter the account number to delete: ";
    cin>>accountNumber;
    hardwarefile.seekg((accountNumber-1)*sizeof(HardwareList));
    HardwareList h;
    hardwarefile.read(reinterpret_cast<char*>(&h),sizeof(HardwareList));
    if(h.getrecordNumber()==0){
        cout<<"No record found for account number "<<accountNumber<<endl;
        return;
    }
    else{
        HardwareList emptyRecord;
        hardwarefile.seekp((accountNumber-1)*sizeof(HardwareList));
        hardwarefile.write(reinterpret_cast<const char*>(&emptyRecord),sizeof(HardwareList));
        cout<<"Record deleted successfully."<<endl;
    }
}