# include<iostream>
# include<fstream>
# include "functions.h"
using namespace std;

int main(){
    fstream OldMaster("oldmaster.txt", ios::in | ios::out | ios::app);
    fstream Transaction("transaction.txt", ios::in | ios::out | ios::app);
    fstream NewMaster("newmaster.txt", ios::in | ios::out | ios::app);
    int numberOfRecords;
    updateMasterFile(OldMaster, Transaction, NewMaster);
    OldMaster.close();
    Transaction.close();
    NewMaster.close();
    return 0;
}