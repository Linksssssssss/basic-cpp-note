# include <iostream>
# include <fstream>
# include <cstdlib>
using namespace std;
int accountNumber;
string firstName;
string lastName;
double currentBalance;
void updateMasterFile(fstream &OldMaster, fstream &Transaction, fstream &NewMaster) {
    int numberOfRecords;
    cout<<"Enter number of records to be added:";
    cin>>numberOfRecords;
    cout<<"Enter account number, name and current balance: \n"<<"?";
    for(int i=0; i<numberOfRecords; i++){
        cin>>accountNumber>>firstName>>lastName>>currentBalance;
        OldMaster<<accountNumber<<' '<<firstName<<' '<<lastName<<' '<<currentBalance<<endl;
        if(i!=numberOfRecords-1){
            cout<<"?";
        }
    }
    double dollarAmount;
    int accountNum;
    int number;
    cout<<"Enter number of transactions to be added:\n";
    cin>>number;
    cout<<"Enter account number, dollar amount for transaction: \n"<<"?";
    OldMaster.clear();
    OldMaster.seekg(0);
    for(int i=0; i<number; i++){
        cin>>accountNum>>dollarAmount;
        Transaction<<accountNum<<' '<<dollarAmount<<endl;
        bool accountFound = false;

        while (OldMaster >> accountNumber >> firstName >> lastName >> currentBalance) {
            if (accountNum == accountNumber) {
                currentBalance += dollarAmount;
                accountFound = true;
                NewMaster << accountNumber << ' ' << firstName << ' ' << lastName << ' ' << currentBalance << endl;
                break;
            }
            else{
                NewMaster << accountNumber << ' ' << firstName << ' ' << lastName << ' ' << currentBalance << endl;
                break;
            }
        }
        if (!accountFound) {
            cout << "Unmatched transaction record for account number .." << accountNum << endl;
        }
        if (i != numberOfRecords - 1) {
            cout << "?";
        }
        else{
            cout << endl;
        }
    }
    NewMaster.clear();
    NewMaster.seekg(0);
    while(NewMaster>>accountNumber>>firstName>>lastName>>currentBalance){
        cout<<accountNumber<<' '<<firstName<<' '<<lastName<<' '<<currentBalance<<endl;
        if(NewMaster.eof()){
            break;
        }
    }
}