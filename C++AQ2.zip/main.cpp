#include <iostream>
#include "Complex.h"
#include <complex>
#include"DoubleSubscriptedArray.h"
using namespace std;


int main()
{
    //testing about Complex
    Complex x;
    Complex y(4.3,8.2);
    Complex z(1.2,6.6);
    x=y*z;
    cout<<x;
    x=y+z;
    cout<<x;
    x=y-z;
    cout<<x;

    cin>>x;
    cout<<x;

    if(y==z)
        cout<<boolalpha<<true<<endl;
    else
        cout<<boolalpha<<false<<endl;
    if(y!=z)
        cout<<boolalpha<<false<<endl;
    else
        cout<<boolalpha<<true<<endl;

    //testing about DoubleSubscriptedArray
    DoubleSubscriptedArray a(3,4);
    DoubleSubscriptedArray b(3,4);
    cin>>a;
    cout<<a;
    b=a;
    b(1,2)=5;
    b(2,3)=a(1,2)+a(2,3);
    if(a==b)
        cout<<boolalpha<<true<<endl;
    else if(a!=b)
        cout<<boolalpha<<false<<endl;
    else
        cout<<boolalpha<<true<<endl;
    return 0;
}