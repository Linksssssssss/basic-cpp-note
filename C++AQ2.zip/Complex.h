# include<iostream>

#ifndef COMPLEX_H
#define COMPLEX_H

class Complex
{
    friend std::istream& operator>>(std::istream& input, Complex& operand2);
    friend std::ostream &operator<<(std::ostream &output, const Complex &operand2);
    public:
    explicit Complex(double =0.0,double =0.0);
    Complex operator+(const Complex &) const;
    Complex operator-(const Complex &) const;
    Complex operator*(const Complex &) const;
    bool operator==(const Complex &) const;
    bool operator!=(const Complex &) const;

private:
    double real;
    double imaginary;
};

#endif