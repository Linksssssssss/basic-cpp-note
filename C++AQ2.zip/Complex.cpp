#include <iostream>
#include "Complex.h"
using namespace std;

Complex::Complex(double realPart, double imaginaryPart)
    : real(realPart),imaginary(imaginaryPart)
{

}
Complex Complex::operator+(const Complex &operand2) const
{
    return Complex(real+operand2.real,imaginary+operand2.imaginary);
}
Complex Complex::operator-(const Complex &operand2) const
{
    return Complex(real-operand2.real,imaginary-operand2.imaginary);
}
Complex Complex::operator*(const Complex &operand2) const
{
    return Complex(real*operand2.real-imaginary*operand2.imaginary,
        real*operand2.imaginary+imaginary*operand2.real);
}
bool Complex::operator==(const Complex &operand2) const
{
    if(real!=operand2.real||imaginary!=operand2.imaginary)
    {
        return false;
    }
    return true;
}
bool Complex::operator!=(const Complex &operand2) const
{
    return !(*this==operand2);
}
istream &operator>>(istream &input,Complex &operand2)
{
    input>>operand2.real>>operand2.imaginary;
    return input;
}
ostream &operator<<(ostream &output, const Complex &operand2)
{
    output<<operand2.real<<'+'<<operand2.imaginary<<'i'<<endl;
    return output;
}