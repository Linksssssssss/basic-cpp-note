#include<iostream>
#include<string>
#include<vector>
#include<array>
#include <iomanip>
#include <stdexcept>

# ifndef DoubleSubscriptedArray_H
# define DoubleSubscriptedArray_H
class DoubleSubscriptedArray
{
friend std::ostream &operator<<(std::ostream &, const  DoubleSubscriptedArray &);
friend std::istream &operator>>(std::istream &,  DoubleSubscriptedArray &);
public:
    DoubleSubscriptedArray(size_t r=0, size_t c=0);
    int operator()(int row, int column) const;
    int & operator()(int row, int column);
    bool operator==(const DoubleSubscriptedArray &right) const;
    bool operator!=(const DoubleSubscriptedArray &right) const;
    DoubleSubscriptedArray &operator=(const DoubleSubscriptedArray &right);
    ~DoubleSubscriptedArray();
private:
    size_t rows;
    size_t columns;
    std::vector<std::vector<int>> array;
};
#endif