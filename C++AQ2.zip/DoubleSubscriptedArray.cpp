#include <iostream>
#include "DoubleSubscriptedArray.h"
using namespace std;

DoubleSubscriptedArray::DoubleSubscriptedArray(size_t r, size_t c)
: rows(r), columns(c), array(rows, std::vector<int>(columns))
{
}

int DoubleSubscriptedArray::operator()(int row, int column) const
{
    if(row<0||row>=rows||column<0||column>=columns)
    {
        throw out_of_range("Subscript out of range");
    }
    return array[row][column];
}
int & DoubleSubscriptedArray::operator()(int row, int column)
{
    if(row<0||row>=rows||column<0||column>=columns)
    {
        throw out_of_range("Subscript out of range");
    }
    return array[row][column];
}
bool DoubleSubscriptedArray::operator==(const DoubleSubscriptedArray &right) const
{
    if ((this->rows!=right.rows)||(this->columns!=right.columns))
    {
        return false;
    }
    else
    {
        for(size_t i=0;i<rows;i++)
        {
            for(size_t j=0;j<columns;j++)
            {
                if(array[i][j]!=right.array[i][j])
                    return false;
            }
        }
    }
    return true;
}
bool DoubleSubscriptedArray::operator!=(const DoubleSubscriptedArray &right) const
{
    return !(*this==right);
}
DoubleSubscriptedArray &DoubleSubscriptedArray::operator=(const DoubleSubscriptedArray &right)
{
    if(&right!=this)
    {
            // if(rows!=right.rows||columns!=right.columns)
            // {
            //     rows=right.rows;
            //     columns=right.columns;
                
            // }
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<columns;j++)
            {
                array[i][j] = right.array[i][j];
            }
        }
    }
    return *this;
}
ostream &operator<<(ostream &output, const DoubleSubscriptedArray &a)
{
    for(size_t i=0;i<a.rows;i++)
    {
        for(size_t j=0;j<a.columns;j++)
        {
            output<<left<<std::setw(12)<<a.array[i][j];

            if((j+1)%4==0)
            {
                output<<std::endl;
            }
        }
    }
    if((a.rows*a.columns)%4!=0)
    {
        output<<std::endl;
    }
    return output;
}
istream &operator>>(istream &input, DoubleSubscriptedArray &a)
{
    for(size_t i=0;i<a.rows;i++)
    {
        for(size_t j=0;j<a.columns;j++)
        {
            input>>a.array[i][j];
        }
    }
    return input;
}
DoubleSubscriptedArray::~DoubleSubscriptedArray()
{
    // Destructor
    // No need to do anything here, as std::vector will automatically deallocate memory
}